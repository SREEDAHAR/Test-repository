package com.cohesiva.deserialize.web;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author Mariusz
 */
@SpringBootApplication
public class ApplicationConfig {

}
